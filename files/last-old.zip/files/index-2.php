<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from clapat.ro/themes/wizzard/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Aug 2018 22:12:16 GMT -->
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
    <script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');
		
		ga('create', 'code here', 'auto');
		ga('send', 'pageview');
	</script>

    <title>Wizzard - Creative Ajax Portfolio Showcase Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Download the best Creative Portfolio HTML Template in 2018" />
    <meta name="author" content="ClaPat Studio">
    <meta charset="UTF-8" />    
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <link href="style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Poppins:500,600" rel="stylesheet">     
    
</head>
    






<body class="hidden">

	<main>
    
    <div class="preloader-wrap">
    	<div class="outer">
        	<div class="inner">
      			<div class="percentage" id="precent"></div>
                <div class="preloader-text">We are a digital and creative agency <span>Wizzard Studio</span></div>      
      		</div>
      	</div>
    </div>
    
	<div class="cd-index cd-main-content">
	
	<!-- Page Content -->
	<div id="page-content" class="" data-bgcolor="#eee">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header class="scroll-hide">
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link" data-type="page-transition" href="index-2.html">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo-white.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <div class="menu-info">Featured Projects</div> 
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
        <div id="menu-overlay">
            
            <div id="close-menu"></div>  
            
            <div class="outer">
                <div class="inner">
                    
                    <nav>                    
                        <ul class="main-menu">
                            <li class="mp active"><a class="ajax-link menu-link" data-type="page-transition" href="index-2.html"><span></span>Home</a></li>
                            <li class="mp has-sub"><a href="#"><span></span>Portfolio</a>
                                <ul>
                                    <li><a class="ajax-link" data-type="page-transition" href="portfolio.html">Visible Text</a></li>
                                    <li><a class="ajax-link" data-type="page-transition" href="portfolio1.html">Black Overlay</a></li>
                                </ul>
                            </li>
                            <li class="mp"><a class="ajax-link menu-link" data-type="page-transition" href="about.html"><span></span>About</a></li>
                            <li class="mp"><a class="ajax-link menu-link" data-type="page-transition" href="contact.html"><span></span>Contact</a></li>
                        </ul>                
                    </nav>
                    
                    
                </div>
            </div>
        
        </div>
        <!-- Menu Overlay -->
        
        
        
        <!-- Showcase Holder -->
        <div id="showcase-holder"> 
            <div id="showcase-slider"> 
            
            
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project01.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/01hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                                               
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Tina Turner</h2>
                            <p class="section-subtitle sa-two">Photography</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->					
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project03.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/03hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Sombre Forest</h2>
                            <p class="section-subtitle sa-two">Photography</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->	
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                   <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project06.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/06hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Sport Black</h2>
                            <p class="section-subtitle sa-two">Design</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->					
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project07.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/07hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Guest House</h2>
                            <p class="section-subtitle sa-two">Photography</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project09.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/09hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Iceland</h2>
                            <p class="section-subtitle sa-two">Photography</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->
                
                
                <!-- Section Slide -->
                <div class="section text-align-center last-slide">
                    
                    <p class="smaller sa-one">Are you ready for more?</p>
                    <h2 class="sa-two">View our entire <br class="destroy">Portfolio projects collection</h2>
                    
                    <hr>
                    
                    <div class="sa-three">
                        <a href="portfolio.html" class="clapat-button rounded outline ajax-link" data-type="page-transition" ><span>See More</span></a>
                    </div>    
                    
                </div>
                <!--/Section Slide -->	                   
                    
                                
            </div>
        </div>    
        <!-- Showcase Holder -->
        
        
        <!-- Footer -->
        <footer class="hidden after-slider">        	
            <div id="footer-container">
            
                <div id="page-action-holder-left" data-tooltip="Prev" data-placement="right">
                    <div id="prev-slide">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </div>
                
                <div id="page-action-holder-right" data-tooltip="Next" data-placement="left">
                    <div id="next-slide">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
                
                <ul class="socials-text">
                    <li><a href="https://www.facebook.com/clapat.ro" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://www.twitter.com/clapatdesign" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.dribbble.com/clapat" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="https://www.behance.net/clapat" target="_blank"><i class="fa fa-behance"></i></a></li>
                </ul>            
                
                <p class="copyright">2018 © <a target="_blank" href="https://www.clapat.com/themes/wizzard/">Wizzard Theme</a>. Design by <a target="_blank" href="https://www.clapat.com/">Clapat</a>.</p> 
            
        	</div>
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    
    <div id="rotate-device"></div>
    
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>


<!-- Mirrored from clapat.ro/themes/wizzard/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Aug 2018 22:12:16 GMT -->
</html>