<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>





	
	<!-- Page Content -->
	<div id="page-content" class="light-content" data-bgcolor="#111">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header class="scroll-hid">
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link" data-type="page-transition" href="index-2.html">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo-white.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
       <?php include "menu.php"; ?>
        <!-- Menu Overlay -->
        
        
        <!-- Main -->
        <div id="main">
        
        
            
            
             <!-- Main Content -->
            <div id="main-content">
            	<div id="main-page-content">           
                
                
                <!-- Row
                <div class="vc_row row_padding_top row_padding_bottom">
                    
                    <div class="container">
                
                		<div id="map_canvas"></div>
                        
					</div>
                    
                </div>
            	--/Row -->
                
                
                <!-- Row -->
                <div class="vc_row small text-align-center row_padding_top has-animation"  data-delay="100">
                    
                    <div class="container">
                        
                        <h4>Let’s talk</h4>
                        <p>For projects or anything else don’t hesitate to get in touch with us. </p>
                       
                        
                        <!-- Contact Formular -->
                        <div id="contact-formular">
                        
                        	<div id="message"></div>
                        
                            <form method="post" action="http://clapat.ro/themes/wizzard/contact.php" name="contactform" id="contactform">                             
                                <div class="name-box">        
                                    <input name="name" type="text" id="name" size="30"  onfocus="if(this.value == 'Full Name') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Full Name'; }" value="Full Name" ><label class="input_label"></label>
                                </div>                                                        
                                <div class="email-box">
                                    <input name="email" type="text" id="email" size="30" onfocus="if(this.value == 'E-mail') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'E-mail'; }" value="E-mail" ><label class="input_label"></label>
                                </div>                            
                                <div class="message-box">
                                    <textarea name="comments" cols="40" rows="4" id="comments" onfocus="if(this.value == 'Your Message') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Your Message'; }" >Your Message</textarea><label class="input_label slow"></label>
                                </div>                             
                                 <div class="submit-box">             
                                    <input type="submit" class="send_message clapat-button outline" id="submit" value="Submit" /> 
                                </div>
                            </form>                        
                                                    
                        </div>
                        <!--/Contact Formular -->
                        
                        <hr><hr>
                        
                    </div>
                    
                </div>
            	<!--/Row -->
            
                <!-- Row -->
                <div class="vc_row text-align-center row_padding_top row_padding_bottom small has-animation"  data-delay="0">
                    
                        <div class="container">
                            
                            <div class="one_third">
                                <div class="clapat-icon">
                                    <i class="fa fa-paper-plane fa-2x" aria-hidden="true"></i>
                                </div>
                            
                                <h6><a href="mailto:info@xpanners.com" class="link"><span>info@xpanners.com</span></a></h6>
                                <p>Email</p>                        
                            </div>
                            
                            <div class="one_third">
                                <div class="clapat-icon">
                                    <i class="fa fa-map-marker fa-2x" aria-hidden="true"></i>
                                </div>
                            
                                <h6> DHA, Karachi, Sindh, Pakistan</h6>
                                <p>Address</p>                        
                            </div>
                            
                            <div class=" one_third last">
                                <div class="clapat-icon">
                                    <i class="fa fa-phone fa-2x" aria-hidden="true"></i>
                                </div>
                            
                                <h6>0092 (315) 256-0565</h6><br> <h6>0092 (333) 352-9343</h6>
                                <p>Phone</p>
                            </div>
                            
                        </div>
                        
                    </div>
                    <!--/Row -->
            
            	</div>
                <!--/Main Page Content -->           
            </div>
            <!--/Main Content --> 
        </div>
        <!--/Main -->       
        
        
        <!-- Footer -->
        <footer class="hidden">        	
            <div id="footer-container">
            	<a id="page-action-holder-left" class="ajax-link" href="portfolio.html" data-type="page-transition" data-tooltip="Back to Works" data-placement="top">
                    <div id="backtoworks">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-times" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </a>
                
                <div id="page-action-holder-right" data-tooltip="Go Top" data-placement="top">
                    <div id="scrolltotop">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-up" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
            
                <?php include("foot.php"); ?>
        	</div>
        
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>



</html>