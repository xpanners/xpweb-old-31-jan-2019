<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>





	
	<!-- Page Content -->
	<div id="page-content" class="light-content" data-bgcolor="#111">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header class="scroll-hid">
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link" data-type="page-transition" href="index-2.html">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo-white.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
        <?php include "menu.php"; ?>
        <!-- Menu Overlay -->
        
        
        <!-- Main -->
        <div id="main">
        
        	
            <!-- Hero Section -->
            <div id="hero" class="has-image">
                <div id="hero-styles" class="opacity-onscroll parallax-onscroll">
                    <div id="hero-caption">
                        <div class="inner">
                            <h1 class="hero-title">XPANNERS PVT LTD.</h1>
                            <p class="hero-subtitle">Our vision is to become the first choice of Clients in the Industry. </p>                        
                        </div>
                    </div>
                    <div class="scroll-down-wrap no-border">
                        <a href="#" class="section-down-arrow ">
							<svg class="nectar-scroll-icon" viewBox="0 0 30 45" enable-background="new 0 0 30 45">
								<path class="nectar-scroll-icon-path" fill="none" stroke="#ffffff" stroke-width="2" stroke-miterlimit="10" d="M15,1.118c12.352,0,13.967,12.88,13.967,12.88v18.76  c0,0-1.514,11.204-13.967,11.204S0.931,32.966,0.931,32.966V14.05C0.931,14.05,2.648,1.118,15,1.118z">
								</path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div id="hero-bg-wrapper">
				<div id="hero-bg-image" class="light-content has-video" style="background-image:url(images/about.jpg)"></div>
            </div> 
            <div id="hero-height" class="hidden"></div>                
            
            
            <!--/Hero Section -->
            
            
             <!-- Main Content -->
            <div id="main-content">
            	<div id="main-page-content">           
                
                
                
                
                	<!-- Row -->
                    <div class="vc_row small row_padding_top  text-align-center">                        
                        <div class="container">
                        
                            <h6 class="has-animation" data-delay="10">
                                Xpaneers development, marketing and support teams are built around qualified people with immense experience in the IT industry. This enables us to be professional and strong in terms of our approach towards the market.
                            </h6>
                            <small>
                                <p>
                                        “ Absolute Customer satisfaction is our highest priority”        
                                </p>
                            </small>
                            
                                
                            
                            <hr><hr><hr><hr><hr><hr><hr>
                            
                            <h4 class="has-animation" data-delay="10">Our clients:</h4>
                            <p class="has-animation" data-delay="10">Proudly served some of the most famous brands:</p>
                            
                            <hr><hr>
                        
                        </div>                    
                    </div>
                    <!--/Row -->
                    
                    
                    
                    <!-- Row -->
                        <div class="vc_row row_padding_bottom text-align-center">                        
                            <div class="container">
                                
                                <!-- Clients Table --> 
                                <ul class="clients-table has-animation" data-delay="10">                        
                                    <li><img src="images/client-jquery.png" alt="client"></li>
                                    <li><img src="images/client-500.png" alt="client"></li>
                                    <li><img src="images/client-sass.png" alt="client"></li>
                                    <li><img src="images/client-airbnb.png" alt="client"></li>   
                                    <li><img src="images/client-github.png" alt="client"></li>
                                    <li><img src="images/client-php.png" alt="client"></li>
                                    <li><img src="images/client-clapat.png" alt="client"></li>
                                    <li><img src="images/client-wp.png" alt="client"></li>                        
                                </ul>
                                <!--/Clients Table -->
                            
                        </div>                    
                    </div>
                    <!--/Row -->
                    
                    
                    
                    
                    <!-- Row -->
                    <div class="vc_row row_padding_top row_padding_bottom text-align-center">
                        
                        <div class="container">                        
                            
                            <p class="has-animation" data-delay="10">What makes us different?</p>
                            <h3 class="has-animation" data-delay="100">Just some of the reasons <br class="destroy">users choose us</h3>
                            
                            <hr><hr>
                            
                            
                            
                            <div class="one_half last has-animation" data-delay="150">
                                <div class="clapat-icon">
                                    <i class="fa fa-repeat" aria-hidden="true"></i>
                                    <h6>Quality</h6>
                                    <p>
                                        <br><br>
                                    <h6>
                                        Customer Focus
                                    </h6><br>
Quality Solutions (QS) maintain a sharp focus on exceeding customer expectations in providing a comprehensive range of onsite, off site and offshore IT services. QS assigns the most qualified and experienced consultants.


                                        <br><h6>
                                        Focus on Quality
                                    </h6><br>
QS delivers the highest quality IT solutions. Our best practices include policies, processes and methodologies all emphasizing a commitment to quality. At QSS, we utilize the Rational Unified Process (RUP)
<br><h6>
    Global Delivery
    
</h6><br>

QS uses global delivery model to provide the ultimate flexibility to our customers in the development, maintenance, and support of their IT systems and applications. We help our customers achieve their goals on-time...
                                    </p>
                                </div>
                            </div>
                            
                            
                            
                            <div class="one_half has-animation" data-delay="150">
                                <div class="clapat-icon">
                                    <i class="fa fa-trophy" aria-hidden="true"></i>
                                    <h6>Innovation</h6>
                                    <p>
                                    
                                   <br><br><h6> Gain Real-Time Visibility</h6><br>
Utilize out-of-the box performance indicators for instant visibility into individual campaigns to measure participation, track status, and monitor potential outcomes for ROI.
<br><br><h6> Achieve Innovation Targetsy</h6><br>

Drive measurable innovation results using consistent, standardized metrics and dashboards to measure overall campaign benefits and improve innovation performance.
<br><br><h6> Reward Innovators</h6><br>

Use Planview’s idea management software to spotlight and celebrate top ideation contributors, advancing the overall corporate culture and brand.
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="one_half last has-animation" data-delay="200">
                                <div class="clapat-icon">
                                    <i class="fa fa-cogs" aria-hidden="true"></i>
                                    <h6>Expertise</h6>
                                    <p>
                                    Xpanners has worked in for leading companies in numerous different industries to further their technological capabilities. We have extensive experience in Development, Our Expert System, Network Solutions , and Multimedia. Our expertise is not limited to any one niche or industry, as it is defined not by our knowledge and experience, but by our methods.

Xpanners applied the Peppers & Rogers One-to-One approach to understanding our customer’s industry, business, and project needs. We achieve a thorough understanding of both our client and their industry and technologies, then deliver customized solutions and services custom-built to meet their unique needs.
                                    </p>
                                </div>
                            </div>
                            
                       <div class="one_half has-animation" data-delay="200">
                                <div class="clapat-icon">
                                    <i class="fa fa-life-ring" aria-hidden="true"></i>
                                    <h6>Friendly Support</h6>
                                    <p>
                                        Our strategy is based on delivering a strong customer value proposition in a niche market. We are looking to offer the best In Services and Products. Our focus is to meet or exceed the customer expectations for an exceptional quality product that is served to be taken out or delivered quickly, and in a friendly manner.
                                        </p>
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                    <!--/Row -->
                    
                    
                    <!-- Row -->
                    <div class="vc_row small row_padding_top row_padding_bottom text-align-center">
                        
                        <div class="container">                        
                            
                            <h3 class="has-animation" data-delay="100">What people are saying about us</h3>
							<hr>
                            
                            <div class="text-carousel has-animation" data-delay="10">
                        
                                <div class="text-carousel-item">
                                    <p>"These guys are amazing. I really like this theme and the customer support is just amazing. <br class="destroy">Thank you for all of your support."</p>                                    <div class="user-review">Sultan0254 - Themeforest</div>
                                </div>
                                
                                
                                <div class="text-carousel-item">
                                    <p>"The design is beautiful, elegant and minimal. The customer service was amazing, asked for a <br class="destroy">404 page and they provided me one free of charge. "</p>
                                    <div class="user-review">Rmbettencourt - Themeforest</div>              
                                </div>
                                
                                
                                <div class="text-carousel-item"> 
                                    <p>"Maestro is one of my favorite theme and I bought quite a few from ThemeForest"</p>
                                    <div class="user-review">Oratorio - Themeforest</div>                     
                                </div>               
                            
                            </div>
                       
                            
                        </div>
                        
                    </div>
                    <!--/Row -->
                    
                    
                    <!-- Row -->
                    <div class="vc_row small row_padding_top row_padding_bottom text-align-center">
                        
                        <div class="container">                        
                            
                            <h2 class="has-animation" data-delay="10">Whatever your needs, we're looking forward to hearing from you</h2>
                            
                            <hr>
                            
                            <a href="contact.html" class="clapat-button rounded outline ajax-link has-animation" data-delay="100" data-type="page-transition" ><span>Contact Us</span></a>
                           
                        </div>
                        
                    </div>
                    <!--/Row -->
                
                
            
            	</div>
                <!--/Main Page Content -->           
            </div>
            <!--/Main Content --> 
        </div>
        <!--/Main -->       
        
        
        <!-- Footer -->
        <footer class="hidden">        	
            <div id="footer-container">
            	<a id="page-action-holder-left" class="ajax-link" href="portfolio.html" data-type="page-transition" data-tooltip="Back to Works" data-placement="top">
                    <div id="backtoworks">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-times" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </a>
                
                <div id="page-action-holder-right" data-tooltip="Go Top" data-placement="top">
                    <div id="scrolltotop">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-up" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
            
              <?php include("foot.php"); ?>
        	</div>
        
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>



</html>