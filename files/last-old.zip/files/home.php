<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>
    







        


	<!-- Page Content -->
	<div id="page-content" class="light-content" oldcolor="#FEFDF2" data-bgcolor="#111">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header class="scroll-hide">
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link"  href="#">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <div class="menu-info">XPANNERS PVT LTD.</div> 
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
       <?php include "menu.php"; ?>
        <!-- Menu Overlay -->
        
        
        
        <!-- Showcase Holder -->
        <div id="showcase-holder"> 
            <div id="showcase-slider"> 
            
            
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask" >
                        <a class="ajax-link-project"  href="https://www.xpanners.com/contact">
                            <div class="img-perspective" >
                                <div class="img-split" style="opacity:0.5;">
                                    <div class="section-image"  data-src="images/01hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                                               
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title sa-one">Our creation is your Destination</h2>
                            <p class="section-subtitle sa-two">Want to Know About Us? </p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->					
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project03.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/03hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h4 class="section-title sa-one">Our commitment to continuous improvement and total quality services.</h4>
                            <p class="section-subtitle sa-two">Our Services</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->	
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                   <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project06.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/06hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h5 class="section-title sa-one">We Built Excellent Products And Services that will build and maintain customer loyaltyk.</h5>
                            <p class="section-subtitle sa-two">See Our Products</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->					
                
                
                <!-- Section Slide -->
                <div class="section light-content">
                    
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project07.html">
                            <div class="img-perspective">
                                <div class="img-split">
                                    <div class="section-image" data-src="images/07hero.jpg"></div>
                                    <div class="section-image-mirror"></div>                        
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                    
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h5 class="section-title sa-one">Need Help?</h5>
                            <p class="section-subtitle sa-two">Lets Get Together</p>
                        </div>
                    </div>
                    
                </div>
                <!--/Section Slide -->
                
                
                
                <!-- Section Slide -->
                <div class="section text-align-center last-slide">
                    
                    <p class="smaller sa-one">Are you ready for more?</p>
                    <h2 class="sa-two">“Absolute Customer satisfaction is our highest priority”</h2>
                    
                    <hr>
                    
                    <div class="sa-three">
                        <a href="#" class="clapat-button rounded outline ajax-link" ><span>See Portfolio</span></a>
                    </div>    
                    
                </div>
                <!--/Section Slide -->	                   
                    
                                
            </div>
        </div>    
        <!-- Showcase Holder -->
        
        
        <!-- Footer -->
        <footer class="hidden after-slider">        	
            <div id="footer-container">
            
                <div id="page-action-holder-left" data-tooltip="Prev" data-placement="right">
                    <div id="prev-slide">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </div>
                
                <div id="page-action-holder-right" data-tooltip="Next" data-placement="left">
                    <div id="next-slide">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
                
                <ul class="socials-text">
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.dribbble.com/" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="https://www.behance.net/" target="_blank"><i class="fa fa-behance"></i></a></li>
                </ul>            
                
                <p class="copyright">2018 © <a target="_blank" href="https://www.xpanners.com/">XPANNERS PVT LTD</a>. Design by <a target="_blank" href="https://www.clapat.com/">xpanners</a>.</p> 
            
        	</div>
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    




    <div id="rotate-device"></div>
    
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>
</html>