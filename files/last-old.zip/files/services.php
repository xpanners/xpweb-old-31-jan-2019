<!DOCTYPE html>
<html lang="en">

    <?php include("head.php");?>	
	<!-- Page Content -->
	<div id="page-content" class="" data-bgcolor="#eee">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header>
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link" data-type="page-transition" href="index-2.html">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo-white.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
      <?php include("menu.php");?>	
        <!-- Menu Overlay -->
        
        
        
        
        
        <!-- Portfolio Filters -->
        <div class="page-action-overlay">
            <div class="outer">
                <div class="inner">                	
                    <div class="close-page-action"></div>
                    <p class="page-action-text">Projects Categories:</p>
                    <ul id="filters" class="page-action-content">
                        <li><a id="all" href="#" data-filter="*" class="active">All</a><span>09</span></li>
                        <li><a href="#" data-filter=".photo">Photography</a><span>03</span></li>                        
                        <li><a href="#" data-filter=".branding">Branding</a><span>03</span></li>                        
                        <li><a href="#" data-filter=".design">Design</a><span>03</span></li>
                    </ul>                   
                </div>
            </div>
        </div>
        <!--/Portfolio Filters -->
        
        
        <!-- Main -->
        <div id="main">
        
        	
            <!-- Hero Section -->
            <div id="hero">
                <div id="hero-styles" class="opacity-onscroll">
                    <div id="hero-caption">
                        <div class="inner">
                            <h1 class="hero-title">Our Services</h1>
                            <p class="hero-subtitle">Our commitment to continuous improvement and total quality services.</p>                        
                        </div>
                    </div>
                </div>
            </div>            
            <div id="hero-height" class="hidden"></div>
            <!--/Hero Section -->
            
            
            <!-- Main Content -->
            <div id="main-content">
                           
                
                <!-- Portfolio Wrap -->
                <div id="portfolio-wrap" class="visible-text">                
                    <!-- Portfolio Columns -->
                    <div id="portfolio" data-col="3">
                        
                        
                        
                        <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="Expert Systems"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">Expert Systems</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                         <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="Network Solutions"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">Network Solutions</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="Development"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">Development</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="Multimedia"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">Multimedia</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                         <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="IT Help Desk"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">IT Help Desk</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item branding">                        	                    	
                            <div class="item-content">
                            	<div class="item-tilt">
                                    <div class="item-shadow is-5o"></div>
                                    <a href="" class="ajax-link" data-type="page-transition">                                    
                                        <div class="item-image" data-src="images/logo.png" alt="Accessories"></div>
                                        <div class="item-gradient"></div>  
                                    </a>
                                    <div class="item-caption">                                
                                        <h2 class="item-title">Accessories</h2>
                                        <h3 class="item-sub-mask">
                                            <span class="item-case">View Details</span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                    <!--/Portfolio -->                
                </div>
                <!--/Portfolio Wrap -->
            
                        
            </div>
            <!--/Main Content --> 
        </div>
        <!--/Main -->       
        
        
        <!-- Footer -->
        <footer class="hidden">        	
        	<div id="footer-container">
                
                <div id="page-action-holder-left" data-tooltip="Filters" data-placement="top">
                    <div id="open-filters">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </div>
                
                <div id="page-action-holder-right" data-tooltip="Go Top" data-placement="top">
                    <div id="scrolltotop">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-up" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
            
               <?php include("head.php");?>	
               
            </div>
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>


<!-- Mirrored from clapat.ro/themes/wizzard/portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Aug 2018 22:12:20 GMT -->
</html>