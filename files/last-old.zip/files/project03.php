<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from clapat.ro/themes/wizzard/project03.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Aug 2018 22:12:43 GMT -->
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');
		
		ga('create', 'code here', 'auto');
		ga('send', 'pageview');
	</script>
    
    <title>Wizzard - Sombre Forest</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Download the best Creative Portfolio HTML Template in 2018" />
    <meta name="author" content="ClaPat Studio">
    <meta charset="UTF-8" />    
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <link href="style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Poppins:500,600" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">        
   
</head>
    






<body class="hidden">

	<main>
    
    <div class="preloader-wrap">
    	<div class="outer">
        	<div class="inner">
      			<div class="percentage" id="precent"></div>
                <div class="preloader-text">We are a digital and creative agency <span>Wizzard Studio</span></div>      
      		</div>
      	</div>
    </div>
    
	<div class="cd-index cd-main-content">
	
	<!-- Page Content -->
	<div id="page-content" class="" data-bgcolor="#eee">
        
        <!-- Background Lines -->
        <div class="bg-lines hidden">    
            <svg>
    			<line x1="20%" y1="100%" x2="80%" y2="0"/>
				<line x1="80%" y1="100%" x2="20%" y2="0"/>
    		</svg>  
        </div>
        <!--/Background Lines -->
        
        
    
        <!-- Header -->
        <header class="scroll-hid">
            <div id="header-container">
        
            <!-- Logo -->
            <div id="logo">
                <a class="ajax-link" data-type="page-transition" href="index-2.html">
                    <img class="black-logo" src="images/logo.png" alt="ClaPat Logo">
                    <img class="white-logo" src="images/logo-white.png" alt="ClaPat Logo">
                </a>
            </div>
            <!--/Logo -->            
            
            <!-- Menu Burger -->
            <div id="burger-wrapper">
            	<div id="burger-circle"></div>
                <div id="menu-burger">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <!--/Menu Burger -->
        
            </div>
        </header>
        <!--/Header -->
        
        
        <!-- Menu Overlay -->
        <div id="menu-overlay">
            
            <div id="close-menu"></div>  
            
            <div class="outer">
                <div class="inner">
                    
                    <nav>                    
                        <ul class="main-menu">
                            <li class="mp"><a class="ajax-link menu-link" data-type="page-transition" href="index-2.html"><span></span>Home</a></li>
                            <li class="mp has-sub active"><a href="#"><span></span>Portfolio</a>
                                <ul>
                                    <li><a class="ajax-link" data-type="page-transition" href="portfolio.html">Visible Text</a></li>
                                    <li><a class="ajax-link" data-type="page-transition" href="portfolio1.html">Black Overlay</a></li>
                                </ul>
                            </li>
                            <li class="mp"><a class="ajax-link menu-link" data-type="page-transition" href="about.html"><span></span>About</a></li>
                            <li class="mp"><a class="ajax-link menu-link" data-type="page-transition" href="contact.html"><span></span>Contact</a></li>
                        </ul>                
                    </nav>
                    
                    
                </div>
            </div>
        
        </div>
        <!-- Menu Overlay -->
        
        
        
        
        
        <!-- Project Share -->
        <div class="page-action-overlay">
            <div class="outer">
                <div class="inner">                	
                    <div class="close-page-action"></div>
                    <p class="page-action-text">Share this Project:</p>
                    <div id="share" class="page-action-content"></div>                    
                </div>
            </div>
        </div>
        <!--/Project Share -->
        
        
        <!-- Main -->
        <div id="main">
        
        	
            <!-- Hero Section -->
            <div id="hero" class="has-image">
                <div id="hero-styles" class="opacity-onscroll parallax-onscroll">
                    <div id="hero-caption">
                        <div class="inner">
                            <h1 class="hero-title">Sombre Forest</h1>
                            <p class="hero-subtitle">Photography</p>                        
                        </div>
                    </div>
                    <div class="scroll-down-wrap no-border">
                        <a href="#" class="section-down-arrow ">
							<svg class="nectar-scroll-icon" viewBox="0 0 30 45" enable-background="new 0 0 30 45">
								<path class="nectar-scroll-icon-path" fill="none" stroke="#ffffff" stroke-width="2" stroke-miterlimit="10" d="M15,1.118c12.352,0,13.967,12.88,13.967,12.88v18.76  c0,0-1.514,11.204-13.967,11.204S0.931,32.966,0.931,32.966V14.05C0.931,14.05,2.648,1.118,15,1.118z">
								</path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div id="hero-bg-wrapper">
				<div id="hero-bg-image" class="light-content" style="background-image:url(images/03hero.jpg)"></div>
            </div> 
            <div id="hero-height" class="hidden"></div>                
            
            
            <!--/Hero Section -->
            
            
            <!-- Main Content -->
            <div id="main-content">
            	<div id="main-page-content">               
                
                    <!-- Row -->
                <div class="vc_row small row_padding_top text-align-center">
                    
                    <div class="container">
                        
                        <h4 class="has-animation" data-delay="10">Digital Photography</h4>
                        
                        <p class="has-animation" data-delay="30">My favourite places on earth are the wild waterways where the forest opens its arms and a silver curve of river folds the traveller into its embrace.</p>
                        
                        <a href="https://www.behance.net/DamienGUIOT" target="_blank" class="link has-animation" data-delay="50" data-type="page-transition" ><span>Damien Guiot</span></a>
                        
                        
                                    
                        
                    </div>
                    
                </div>
                <!--/Row -->               
                
                
                <!-- Row -->
                <div class="vc_row full row_padding_top">
                    
                    <div class="container">
                        
                        <!-- Collage -->
                        <div class="collage">
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="10">                
                                <a class="image-link" href="images/projects/bf01.jpg">
                                    <img src="images/projects/bf01.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="130">                          
                                <a class="image-link" href="images/projects/bf02.jpg">
                                    <img src="images/projects/bf02.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="260">               
                                <a class="image-link" href="images/projects/bf03.jpg">
                                    <img src="images/projects/bf03.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="110">                      
                                <a class="image-link" href="images/projects/bf04.jpg">
                                    <img src="images/projects/bf04.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="230">                           
                                <a class="image-link" href="images/projects/bf05.jpg">
                                    <img src="images/projects/bf05.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="360">            
                                <a class="image-link" href="images/projects/bf06.jpg">
                                    <img src="images/projects/bf06.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="10">                         
                                <a class="image-link" href="images/projects/bf07.jpg">
                                    <img src="images/projects/bf07.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="130">                        
                                <a class="image-link" href="images/projects/bf08.jpg">
                                    <img src="images/projects/bf08.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="260">                        
                                <a class="image-link" href="images/projects/bf09.jpg">
                                    <img src="images/projects/bf09.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="110">                        
                                <a class="image-link" href="images/projects/bf10.jpg">
                                    <img src="images/projects/bf10.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            <!-- Collage item with pop-up -->
                            <div class="collage-thumb has-animation" data-delay="230">                        
                                <a class="image-link" href="images/projects/bf11.jpg">
                                    <img src="images/projects/bf11.jpg" alt="img" />
                                    <div class="thumb-info"><h6>Sombre Forest</h6></div>
                                </a>
                            </div>
                            
                            
                        </div>
                        <!--/Collage -->
                                    
                        
                    </div>
                    
                </div>
                <!--/Row -->                    
            
                </div>
                <!--/Main Page Content --> 
                
                <!-- Project Navigation --> 
                <div id="project-nav" class="section light-content">
                
                	<div class="next-project-info">Next Project</div> 
                
                    <div class="img-mask">
                        <a class="ajax-link-project" data-type="page-transition" href="project04.html">
                            <div class="img-perspective">
                            	<div class="img-split">
                                	<div class="section-image" data-src="images/04hero.jpg"></div>
                                </div>
                            </div>
                         </a>
                    </div>
                    
                    <div class="section-shadow"></div>
                            
                    <div class="section-caption-outer">
                        <div class="section-caption-inner">
                            <h2 class="section-title">Ex Machina</h2>
                            <p class="section-subtitle">Design</p>
                        </div>
                    </div>
                    
                </div>      
                <!--/Project Navigation -->
                
                            
            </div>
            <!--/Main Content --> 
        </div>
        <!--/Main --> 
        
        
        
        <!-- Footer -->
        <footer class="hidden">        	
        	<div id="footer-container">
                
                <div id="page-action-holder-left" data-tooltip="Share" data-placement="top">
                    <div id="open-filters">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="20px" y="20px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-share-alt" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>                        	
                </div>
                
                <div id="page-action-holder-right" data-tooltip="Go Top" data-placement="top">
                    <div id="scrolltotop">                                                    
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="10px" y="10px" width="40px" height="40px" viewBox="0 0 80 80" xml:space="preserve">
                            <circle class="circle-action is-inner" cx="40" cy="40" r="36" />
                            <circle class="circle-action is-outer" cx="40" cy="40" r="36" />
                        </svg>
                        <i class="fa fa-chevron-up" aria-hidden="true"></i>
                        <div class="circle-line"></div>
                    </div>
                </div>
            
                <ul class="socials-text">
                    <li><a href="https://www.facebook.com/clapat.ro" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://www.twitter.com/clapatdesign" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.dribbble.com/clapat" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="https://www.behance.net/clapat" target="_blank"><i class="fa fa-behance"></i></a></li>
                </ul>            
                
                <p class="copyright">2018 © <a target="_blank" href="https://www.clapat.com/themes/wizzard/">Wizzard Theme</a>. Design by <a target="_blank" href="https://www.clapat.com/">Clapat</a>.</p>
                
            </div>
        </footer>
        <!--/Footer -->
 
 
	</div>    
	<!--/Page Content -->
    
    </div>
</main>
    
    
    <div class="cd-cover-layer"></div>
    
		
    <script src="js/jquery.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>



</body>


<!-- Mirrored from clapat.ro/themes/wizzard/project03.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Aug 2018 22:14:23 GMT -->
</html>