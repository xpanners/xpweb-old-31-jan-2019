<head>
	
    <script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');
		
		ga('create', 'code here', 'auto');
		ga('send', 'pageview');
	</script>

    <title>XPANNERS PVT LTD</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="XPANNERS PVT LTD" />
    <meta name="author" content="XPANNERS PVT LTD">
    <meta charset="UTF-8" />    
    <link rel="icon" type="image/png" href="images/logo.png" />
    <link href="style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Poppins:500,600" rel="stylesheet">     
    
</head>
<body class="hidden">   

	<main>
    
    <div class="preloader-wrap">
    	<div class="outer">
        	<div class="inner">
      			<div class="percentage" id="precent"></div>
                <div class="preloader-text"><b>Our creation is your Destination <span>XPANNERS PVT LTD.</span></b></div>      
      		</div>
      	</div>
    </div>
    
	<div class="cd-index cd-main-content">
    