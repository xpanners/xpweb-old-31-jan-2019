  
        <?php
        $use_sts = TRUE; if ($use_sts && isset($_SERVER['HTTPS'])) { header('Strict-Transport-Security: max-age=500'); } elseif ($use_sts && !isset($_SERVER['HTTPS'])) { header('Status-Code: 301'); header('Location: https://'.$_SERVER["HTTP_HOST"].$_SERVER['REQUEST_URI']); }
        $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $url = explode('/',$url);
        $url = array_slice($url,1);
        $params = array_slice($url,1);
        
        $file = 'files/'.$url[0].'.php';
        if(file_exists($file)){
              include($file);
        }else{
            include("files/home.php");
        }



        ?>