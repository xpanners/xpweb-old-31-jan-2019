<ul class="socials-text">
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.dribbble.com/" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="https://www.behance.net/" target="_blank"><i class="fa fa-behance"></i></a></li>
                </ul>            
                
                <p class="copyright">2018 © <a target="_blank" href="https://www.xpanners.com/">XPANNERS PVT LTD</a>. Design by <a target="_blank" href="https://www.xpanners.com">xpanners</a>.</p> 