<!DOCTYPE html>
<html>
<head>
    <title><?php echo constant("title"); ?></title>
    <!-- Metadata -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo constant("logo"); ?>" />
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="assets/css/plugins.min.css">
    <!-- Custom CSS File -->
    <link rel="stylesheet" href="assets/css/style.css">
  </head>

  <body>
    <div class="ms-main-container">
      <!-- Preloader -->
      <div class="ms-preloader"></div>
      <!-- Header -->
      <header class="ms-header">
        <nav class="ms-nav">
          <div class="ms-logo">
            <a href="index-2.html" data-type="page-transition">
              <div class="logo-dark current"><img src="<?php echo constant("logo"); ?>" alt="logo image"></div>
              <div class="logo-light"><img src="<?php echo constant("logo"); ?>" alt="logo image"></div>
            </a>
          </div>
          <button class="hamburger" type="button" data-toggle="navigation">
            <span class="hamburger-box">
              <span class="hamburger-label">menu</span>
              <span class="hamburger-inner"></span>
            </span>
          </button>
          <div class="height-full-viewport">
            <ul class="ms-navbar">
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="index-2.html" data-type="page-transition">
                  <span class="ms-btn">home</span>
                  <span class="nav-item__label">Back to home page</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="albums.html" data-type="page-transition">
                  <span class="ms-btn">albums</span>
                  <span class="nav-item__label">View all our works</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="gallery.html" data-type="page-transition">
                  <span class="ms-btn">gallery</span>
                  <span class="nav-item__label">Interactively disintermediate</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="blog.html" data-type="page-transition">
                  <span class="ms-btn">blog</span>
                  <span class="nav-item__label">Discover fascinating stories</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="about.html" data-type="page-transition">
                  <span class="ms-btn">about</span>
                  <span class="nav-item__label">Learn more about the author</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="contact.html" data-type="page-transition">
                  <span class="ms-btn">contact</span>
                  <span class="nav-item__label">Get in touch and find us</span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Container -->
      <main class="ms-container">
        <!-- Page Title -->
        <div class="ms-section__block">
          <div class="ms-page-title">
            <h2 class="page-header">Let's work together</h2>
            <p class="page-desc">Assertively synthesize state of the art testing procedures via sticky niches.</p>
          </div>
        </div>
        <!-- Page Content -->
        <div class="ms-section__block">
          <div id="contact" class="row">
          <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                  <h6>the office</h6>
                  <p>25 Parker St. London WC2B 5PJ UK</p>
                </div>
                <div class="col-md-6">
                  <h6>telephone</h6>
                  <p>+44 (0)20 7830 1387</p>
                </div>
                <div class="col-md-6">
                  <h6>email</h6>
                  <p>test@mail.com</p>
                </div>
                <div class="col-md-6 cont-soc">
                  <h6>social</h6>
                  <p>
                    <a href="#" class="socicon-facebook"></a>
                    <a href="#" class="socicon-instagram"></a>
                    <a href="#" class="socicon-twitter"></a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <h6>Get in touch</h6>
              <form id="validForm">
                <div class="row">
                  <div class="form-group col-md-6">
                    <input type="text" name="name" class="form-control" id="cl" placeholder="Your name" autocomplete="off">
                  </div>
                  <div class="form-group col-md-6">
                    <input type="email" name="email" class="form-control" placeholder="Email address" autocomplete="off">
                  </div>
                  <div class="form-group col-md-12">
                    <input type="text" name="subject" class="form-control" placeholder="Subject">
                  </div>
                  <div class="form-group col-md-12">
                    <textarea name="message" class="form-control" id="message" placeholder="Your message"></textarea>
                  </div>
                  <div class="col-md-12">
                    <div class="ms-button" data-title="send">Send
                      <input type="submit" value="send">
                    </div>
                  </div>
                </div>
              </form>
            </div>
            </div>
        </div>
      </main>
      <!-- Footer -->
      <footer>
        <div class="ms-footer">
          <div class="copyright">Copyright © 2017. Design by MadSparrow</div>
          <ul class="socials">
            <li><a href="#" class="socicon-facebook"></a></li>
            <li><a href="#" class="socicon-twitter"></a></li>
            <li><a href="#" class="socicon-instagram"></a></li>
            <li><a href="#" class="socicon-youtube"></a></li>
          </ul>
        </div>
      </footer>
    </div>
    <!-- JS Libraries -->
    <!-- jquery-2.1.3.min js -->
    <script type="text/javascript" src='assets/js/jquery-3.2.1.min.js'></script>
    <!-- Vendors -->
    <script type="text/javascript" src='assets/js/plugins.min.js'></script>
    <!-- Main js -->
    <script type="text/javascript" src="assets/js/main.js"></script>
  </body>


<!-- Mirrored from madsparrow.me/emily/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Sep 2018 09:31:37 GMT -->
</html>