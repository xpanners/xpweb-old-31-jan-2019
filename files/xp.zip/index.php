<?php

define('title','XPANNERS PVT LTD');
define('logo','logo.png');



$url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$url = explode('/',$url);
$url = array_slice($url,2);

switch($url[0]){
    default:
    case"home":
    include "home.php";
    break;
    case"about":
    include "about.php";
    break;
    case"contact":
    include "contact.php";
    break;
    case"services":
    include "services.php";
    break;
    case"products":
    include "products.php";
    break;
    
}


?>