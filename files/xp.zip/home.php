<!DOCTYPE html>
<html>
  
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title><?php echo constant("title"); ?></title>
    <!-- Metadata -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo constant("logo"); ?>" />
    <!-- CSS Plugins -->
    <link rel="stylesheet" href="assets/css/plugins.min.css">
    <!-- Custom CSS File -->
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <div class="ms-main-container">
      <!-- Preloader -->
      <div class="ms-preloader"></div>
      <!-- Header -->
      <header class="ms-header navbar-white">
        <nav class="ms-nav">
          <div class="ms-logo">
            <a href="index-2.html" data-type="page-transition">
              <div class="logo-dark"><img src="<?php echo constant("logo"); ?>" alt="logo image"></div>
              <div class="logo-light current"><img src="<?php echo constant("logo"); ?>" alt="logo image"></div>
            </a>
          </div>
          <button class="hamburger" type="button" data-toggle="navigation">
          <span class="hamburger-box">
            <span class="hamburger-label">find</span>
            <span class="hamburger-inner"></span>
          </span>
          </button>
          <div class="height-full-viewport">
            <ul class="ms-navbar">
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="" data-type="page-transition">
                  <span class="ms-btn">home</span>
                  <span class="nav-item__label">Back to home page</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="albums.html" data-type="page-transition">
                  <span class="ms-btn">Services</span>
                  <span class="nav-item__label">Services We Provide</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="gallery.html" data-type="page-transition">
                  <span class="ms-btn">Products</span>
                  <span class="nav-item__label">Discover Our Products</span>
                </a>
              </li>
              <!-- Nav Link 
              <li class="nav-item">
                <a href="blog.html" data-type="page-transition">
                  <span class="ms-btn">blog</span>
                  <span class="nav-item__label">Discover fascinating stories</span>
                </a>
              </li>
              Nav Link -->
              <li class="nav-item">
                <a href="about.html" data-type="page-transition">
                  <span class="ms-btn">about</span>
                  <span class="nav-item__label">Get To Know About Us</span>
                </a>
              </li>
              <!-- Nav Link -->
              <li class="nav-item">
                <a href="contact.html" data-type="page-transition">
                  <span class="ms-btn">contact</span>
                  <span class="nav-item__label">Get in touch and find us</span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Container -->
      <main class="ms-container home-slider">
        <!-- Swiper Slider -->
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <!-- Slide -->
            <div class="swiper-slide">
              <div class="slide-inner" data-swiper-parallax="45%">
                <div class="overlay"></div>
                <div class="slide-inner--image" style="background-image: url('assets/images/2.jpg');-webkit-filter: blur(5px);-moz-filter: blur(5px);-o-filter: blur(5px);-ms-filter: blur(5px);filter: blur(5px);"></div>
                <div class="slide-inner--info">
                  <h4 style="color: white;">Our Vision</h4>
                  <p style="color: white; margin-top: -40px;">Our vision is to become the first choice of Clients in the Industry.</p>
                  <a href="" data-type="page-transition" class="ms-btn--slider">about us</a>
                </div>
              </div>
            </div>
            <!-- Slide -->
            <div class="swiper-slide">
              <div class="slide-inner" data-swiper-parallax="45%">
                <div class="overlay"></div>
                <div class="slide-inner--image" style="background-image: url('assets/images/1.jpg');-webkit-filter: blur(5px);-moz-filter: blur(5px);-o-filter: blur(5px);-ms-filter: blur(5px);filter: blur(5px);">
                </div>
                <div class="slide-inner--info">
                  <h4 style="color: white;">Our Services</h4>
                  <p style="color: white; margin-top: -40px;">Our commitment is to continuous improvement and total quality services.</p>
                  <a href="" data-type="page-transition" class="ms-btn--slider">take a look</a>
                </div>
              </div>
            </div>
            <!-- Slide -->
            <div class="swiper-slide">
              <div class="slide-inner" data-swiper-parallax="45%">
                <div class="overlay"></div>
                <div class="slide-inner--image" style="background-image: url('assets/images/3.jpg');-webkit-filter: blur(5px);-moz-filter: blur(5px);-o-filter: blur(5px);-ms-filter: blur(5px);filter: blur(5px);">
                </div>
                <div class="slide-inner--info">
                  <h4 style="color: white;">Our Products</h4>
                  <p style="color: white; margin-top: -40px;">Excellent Products that will build and maintain customer loyalty.</p>
                  <a href="" data-type="page-transition" class="ms-btn--slider">checkout</a>
                </div>
              </div>
            </div>
            <!-- Slide -->
            <div class="swiper-slide">
              <div class="slide-inner" data-swiper-parallax="45%">
                <div class="overlay"></div>
                <div class="slide-inner--image" style="background-image: url('assets/images/4.jpg');-webkit-filter: blur(5px);-moz-filter: blur(5px);-o-filter: blur(5px);-ms-filter: blur(5px);filter: blur(5px);">
                </div>
                <div class="slide-inner--info">
                  <h4 style="color: white;">Our Guarantee</h4>
                  <p style="color: white; margin-top: -40px;">Absolute Customer satisfaction is our highest priority.</p>
                  <a href="" data-type="page-transition" class="ms-btn--slider">contact us</a>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-nav-btn">
            <div class="swiper-button-prev swiper-button-white">prev</div>
            <div class="swiper-button-next swiper-button-white">next</div>
          </div>
          <!-- Pagination -->
          <div class="expanded-timeline">
            <div class="expanded-timeline__counter"><span></span><span></span></div>
            <div class="swiper-pagination"></div>
            <div class="scroll-message">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.5 15.98" class="scroll-svg"><title>Asset 1</title><g>
              <g data-name="Layer 1"><polygon fill="#fff" points="0 4.64 0.71 5.34 3.85 2.2 3.85 15.98 4.85 15.98 4.85 2.2 8 5.34 8.71 4.64 4.35 0.29 0 4.64"></polygon><polygon fill="#fff" points="11.65 0 11.65 13.79 8.5 10.64 7.79 11.35 12.15 15.7 16.5 11.35 15.79 10.64 12.65 13.79 12.65 0 11.65 0"></polygon></g></g></svg>Scroll
            </div>
          </div>
        </div>
      </main>
      <!-- /Container -->
    </div>
    <!-- JS Libraries -->
    <!-- jquery-2.1.3.min js -->
    <script type="text/javascript" src='assets/js/jquery-3.2.1.min.js'></script>
    <!-- Vendors -->
    <script type="text/javascript" src='assets/js/plugins.min.js'></script>
    <!-- Main js -->
    <script type="text/javascript" src="assets/js/main.js"></script>
  </body>
</html>